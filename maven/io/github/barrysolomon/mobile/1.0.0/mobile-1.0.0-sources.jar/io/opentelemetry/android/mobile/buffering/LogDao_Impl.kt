package io.opentelemetry.android.mobile.buffering

import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.util.appendPlaceholders
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.getTotalChangedRows
import androidx.room.util.performSuspending
import androidx.sqlite.SQLiteStatement
import javax.`annotation`.processing.Generated
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass
import kotlin.text.StringBuilder

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
internal class LogDao_Impl(
  __db: RoomDatabase,
) : LogDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfLogRecordEntity: EntityInsertAdapter<LogRecordEntity>
  init {
    this.__db = __db
    this.__insertAdapterOfLogRecordEntity = object : EntityInsertAdapter<LogRecordEntity>() {
      protected override fun createQuery(): String = "INSERT OR ABORT INTO `log_records` (`id`,`timestampMs`,`severityText`,`body`,`attributes`,`resource`,`instrumentationScopeName`,`instrumentationScopeVersion`,`traceId`,`spanId`,`attributeTypes`,`monotonicMs`,`bootId`,`seqId`) VALUES (nullif(?, 0),?,?,?,?,?,?,?,?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: LogRecordEntity) {
        statement.bindLong(1, entity.id)
        statement.bindLong(2, entity.timestampMs)
        val _tmpSeverityText: String? = entity.severityText
        if (_tmpSeverityText == null) {
          statement.bindNull(3)
        } else {
          statement.bindText(3, _tmpSeverityText)
        }
        statement.bindText(4, entity.body)
        statement.bindText(5, entity.attributes)
        statement.bindText(6, entity.resource)
        val _tmpInstrumentationScopeName: String? = entity.instrumentationScopeName
        if (_tmpInstrumentationScopeName == null) {
          statement.bindNull(7)
        } else {
          statement.bindText(7, _tmpInstrumentationScopeName)
        }
        val _tmpInstrumentationScopeVersion: String? = entity.instrumentationScopeVersion
        if (_tmpInstrumentationScopeVersion == null) {
          statement.bindNull(8)
        } else {
          statement.bindText(8, _tmpInstrumentationScopeVersion)
        }
        val _tmpTraceId: String? = entity.traceId
        if (_tmpTraceId == null) {
          statement.bindNull(9)
        } else {
          statement.bindText(9, _tmpTraceId)
        }
        val _tmpSpanId: String? = entity.spanId
        if (_tmpSpanId == null) {
          statement.bindNull(10)
        } else {
          statement.bindText(10, _tmpSpanId)
        }
        val _tmpAttributeTypes: String? = entity.attributeTypes
        if (_tmpAttributeTypes == null) {
          statement.bindNull(11)
        } else {
          statement.bindText(11, _tmpAttributeTypes)
        }
        statement.bindLong(12, entity.monotonicMs)
        val _tmpBootId: String? = entity.bootId
        if (_tmpBootId == null) {
          statement.bindNull(13)
        } else {
          statement.bindText(13, _tmpBootId)
        }
        statement.bindLong(14, entity.seqId)
      }
    }
  }

  public override suspend fun insertAll(logs: List<LogRecordEntity>): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfLogRecordEntity.insert(_connection, logs)
  }

  public override suspend fun getEventsAfter(startMs: Long): List<LogRecordEntity> {
    val _sql: String = "SELECT * FROM log_records WHERE timestampMs >= ? ORDER BY timestampMs ASC"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, startMs)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfTimestampMs: Int = getColumnIndexOrThrow(_stmt, "timestampMs")
        val _columnIndexOfSeverityText: Int = getColumnIndexOrThrow(_stmt, "severityText")
        val _columnIndexOfBody: Int = getColumnIndexOrThrow(_stmt, "body")
        val _columnIndexOfAttributes: Int = getColumnIndexOrThrow(_stmt, "attributes")
        val _columnIndexOfResource: Int = getColumnIndexOrThrow(_stmt, "resource")
        val _columnIndexOfInstrumentationScopeName: Int = getColumnIndexOrThrow(_stmt, "instrumentationScopeName")
        val _columnIndexOfInstrumentationScopeVersion: Int = getColumnIndexOrThrow(_stmt, "instrumentationScopeVersion")
        val _columnIndexOfTraceId: Int = getColumnIndexOrThrow(_stmt, "traceId")
        val _columnIndexOfSpanId: Int = getColumnIndexOrThrow(_stmt, "spanId")
        val _columnIndexOfAttributeTypes: Int = getColumnIndexOrThrow(_stmt, "attributeTypes")
        val _columnIndexOfMonotonicMs: Int = getColumnIndexOrThrow(_stmt, "monotonicMs")
        val _columnIndexOfBootId: Int = getColumnIndexOrThrow(_stmt, "bootId")
        val _columnIndexOfSeqId: Int = getColumnIndexOrThrow(_stmt, "seqId")
        val _result: MutableList<LogRecordEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: LogRecordEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpTimestampMs: Long
          _tmpTimestampMs = _stmt.getLong(_columnIndexOfTimestampMs)
          val _tmpSeverityText: String?
          if (_stmt.isNull(_columnIndexOfSeverityText)) {
            _tmpSeverityText = null
          } else {
            _tmpSeverityText = _stmt.getText(_columnIndexOfSeverityText)
          }
          val _tmpBody: String
          _tmpBody = _stmt.getText(_columnIndexOfBody)
          val _tmpAttributes: String
          _tmpAttributes = _stmt.getText(_columnIndexOfAttributes)
          val _tmpResource: String
          _tmpResource = _stmt.getText(_columnIndexOfResource)
          val _tmpInstrumentationScopeName: String?
          if (_stmt.isNull(_columnIndexOfInstrumentationScopeName)) {
            _tmpInstrumentationScopeName = null
          } else {
            _tmpInstrumentationScopeName = _stmt.getText(_columnIndexOfInstrumentationScopeName)
          }
          val _tmpInstrumentationScopeVersion: String?
          if (_stmt.isNull(_columnIndexOfInstrumentationScopeVersion)) {
            _tmpInstrumentationScopeVersion = null
          } else {
            _tmpInstrumentationScopeVersion = _stmt.getText(_columnIndexOfInstrumentationScopeVersion)
          }
          val _tmpTraceId: String?
          if (_stmt.isNull(_columnIndexOfTraceId)) {
            _tmpTraceId = null
          } else {
            _tmpTraceId = _stmt.getText(_columnIndexOfTraceId)
          }
          val _tmpSpanId: String?
          if (_stmt.isNull(_columnIndexOfSpanId)) {
            _tmpSpanId = null
          } else {
            _tmpSpanId = _stmt.getText(_columnIndexOfSpanId)
          }
          val _tmpAttributeTypes: String?
          if (_stmt.isNull(_columnIndexOfAttributeTypes)) {
            _tmpAttributeTypes = null
          } else {
            _tmpAttributeTypes = _stmt.getText(_columnIndexOfAttributeTypes)
          }
          val _tmpMonotonicMs: Long
          _tmpMonotonicMs = _stmt.getLong(_columnIndexOfMonotonicMs)
          val _tmpBootId: String?
          if (_stmt.isNull(_columnIndexOfBootId)) {
            _tmpBootId = null
          } else {
            _tmpBootId = _stmt.getText(_columnIndexOfBootId)
          }
          val _tmpSeqId: Long
          _tmpSeqId = _stmt.getLong(_columnIndexOfSeqId)
          _item = LogRecordEntity(_tmpId,_tmpTimestampMs,_tmpSeverityText,_tmpBody,_tmpAttributes,_tmpResource,_tmpInstrumentationScopeName,_tmpInstrumentationScopeVersion,_tmpTraceId,_tmpSpanId,_tmpAttributeTypes,_tmpMonotonicMs,_tmpBootId,_tmpSeqId)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getAllEvents(): List<LogRecordEntity> {
    val _sql: String = "SELECT * FROM log_records ORDER BY timestampMs ASC"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfTimestampMs: Int = getColumnIndexOrThrow(_stmt, "timestampMs")
        val _columnIndexOfSeverityText: Int = getColumnIndexOrThrow(_stmt, "severityText")
        val _columnIndexOfBody: Int = getColumnIndexOrThrow(_stmt, "body")
        val _columnIndexOfAttributes: Int = getColumnIndexOrThrow(_stmt, "attributes")
        val _columnIndexOfResource: Int = getColumnIndexOrThrow(_stmt, "resource")
        val _columnIndexOfInstrumentationScopeName: Int = getColumnIndexOrThrow(_stmt, "instrumentationScopeName")
        val _columnIndexOfInstrumentationScopeVersion: Int = getColumnIndexOrThrow(_stmt, "instrumentationScopeVersion")
        val _columnIndexOfTraceId: Int = getColumnIndexOrThrow(_stmt, "traceId")
        val _columnIndexOfSpanId: Int = getColumnIndexOrThrow(_stmt, "spanId")
        val _columnIndexOfAttributeTypes: Int = getColumnIndexOrThrow(_stmt, "attributeTypes")
        val _columnIndexOfMonotonicMs: Int = getColumnIndexOrThrow(_stmt, "monotonicMs")
        val _columnIndexOfBootId: Int = getColumnIndexOrThrow(_stmt, "bootId")
        val _columnIndexOfSeqId: Int = getColumnIndexOrThrow(_stmt, "seqId")
        val _result: MutableList<LogRecordEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: LogRecordEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpTimestampMs: Long
          _tmpTimestampMs = _stmt.getLong(_columnIndexOfTimestampMs)
          val _tmpSeverityText: String?
          if (_stmt.isNull(_columnIndexOfSeverityText)) {
            _tmpSeverityText = null
          } else {
            _tmpSeverityText = _stmt.getText(_columnIndexOfSeverityText)
          }
          val _tmpBody: String
          _tmpBody = _stmt.getText(_columnIndexOfBody)
          val _tmpAttributes: String
          _tmpAttributes = _stmt.getText(_columnIndexOfAttributes)
          val _tmpResource: String
          _tmpResource = _stmt.getText(_columnIndexOfResource)
          val _tmpInstrumentationScopeName: String?
          if (_stmt.isNull(_columnIndexOfInstrumentationScopeName)) {
            _tmpInstrumentationScopeName = null
          } else {
            _tmpInstrumentationScopeName = _stmt.getText(_columnIndexOfInstrumentationScopeName)
          }
          val _tmpInstrumentationScopeVersion: String?
          if (_stmt.isNull(_columnIndexOfInstrumentationScopeVersion)) {
            _tmpInstrumentationScopeVersion = null
          } else {
            _tmpInstrumentationScopeVersion = _stmt.getText(_columnIndexOfInstrumentationScopeVersion)
          }
          val _tmpTraceId: String?
          if (_stmt.isNull(_columnIndexOfTraceId)) {
            _tmpTraceId = null
          } else {
            _tmpTraceId = _stmt.getText(_columnIndexOfTraceId)
          }
          val _tmpSpanId: String?
          if (_stmt.isNull(_columnIndexOfSpanId)) {
            _tmpSpanId = null
          } else {
            _tmpSpanId = _stmt.getText(_columnIndexOfSpanId)
          }
          val _tmpAttributeTypes: String?
          if (_stmt.isNull(_columnIndexOfAttributeTypes)) {
            _tmpAttributeTypes = null
          } else {
            _tmpAttributeTypes = _stmt.getText(_columnIndexOfAttributeTypes)
          }
          val _tmpMonotonicMs: Long
          _tmpMonotonicMs = _stmt.getLong(_columnIndexOfMonotonicMs)
          val _tmpBootId: String?
          if (_stmt.isNull(_columnIndexOfBootId)) {
            _tmpBootId = null
          } else {
            _tmpBootId = _stmt.getText(_columnIndexOfBootId)
          }
          val _tmpSeqId: Long
          _tmpSeqId = _stmt.getLong(_columnIndexOfSeqId)
          _item = LogRecordEntity(_tmpId,_tmpTimestampMs,_tmpSeverityText,_tmpBody,_tmpAttributes,_tmpResource,_tmpInstrumentationScopeName,_tmpInstrumentationScopeVersion,_tmpTraceId,_tmpSpanId,_tmpAttributeTypes,_tmpMonotonicMs,_tmpBootId,_tmpSeqId)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getCount(): Int {
    val _sql: String = "SELECT COUNT(*) FROM log_records"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getTotalLogicalBytes(): Long {
    val _sql: String = "SELECT COALESCE(SUM(LENGTH(body) + LENGTH(attributes) + LENGTH(resource)), 0) FROM log_records"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _result: Long
        if (_stmt.step()) {
          val _tmp: Long
          _tmp = _stmt.getLong(0)
          _result = _tmp
        } else {
          _result = 0L
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getMaxSeqId(): Long? {
    val _sql: String = "SELECT MAX(seqId) FROM log_records"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _result: Long?
        if (_stmt.step()) {
          val _tmp: Long?
          if (_stmt.isNull(0)) {
            _tmp = null
          } else {
            _tmp = _stmt.getLong(0)
          }
          _result = _tmp
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getEventsByTraceId(traceId: String): List<LogRecordEntity> {
    val _sql: String = "SELECT * FROM log_records WHERE traceId = ? ORDER BY timestampMs ASC"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, traceId)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfTimestampMs: Int = getColumnIndexOrThrow(_stmt, "timestampMs")
        val _columnIndexOfSeverityText: Int = getColumnIndexOrThrow(_stmt, "severityText")
        val _columnIndexOfBody: Int = getColumnIndexOrThrow(_stmt, "body")
        val _columnIndexOfAttributes: Int = getColumnIndexOrThrow(_stmt, "attributes")
        val _columnIndexOfResource: Int = getColumnIndexOrThrow(_stmt, "resource")
        val _columnIndexOfInstrumentationScopeName: Int = getColumnIndexOrThrow(_stmt, "instrumentationScopeName")
        val _columnIndexOfInstrumentationScopeVersion: Int = getColumnIndexOrThrow(_stmt, "instrumentationScopeVersion")
        val _columnIndexOfTraceId: Int = getColumnIndexOrThrow(_stmt, "traceId")
        val _columnIndexOfSpanId: Int = getColumnIndexOrThrow(_stmt, "spanId")
        val _columnIndexOfAttributeTypes: Int = getColumnIndexOrThrow(_stmt, "attributeTypes")
        val _columnIndexOfMonotonicMs: Int = getColumnIndexOrThrow(_stmt, "monotonicMs")
        val _columnIndexOfBootId: Int = getColumnIndexOrThrow(_stmt, "bootId")
        val _columnIndexOfSeqId: Int = getColumnIndexOrThrow(_stmt, "seqId")
        val _result: MutableList<LogRecordEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: LogRecordEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpTimestampMs: Long
          _tmpTimestampMs = _stmt.getLong(_columnIndexOfTimestampMs)
          val _tmpSeverityText: String?
          if (_stmt.isNull(_columnIndexOfSeverityText)) {
            _tmpSeverityText = null
          } else {
            _tmpSeverityText = _stmt.getText(_columnIndexOfSeverityText)
          }
          val _tmpBody: String
          _tmpBody = _stmt.getText(_columnIndexOfBody)
          val _tmpAttributes: String
          _tmpAttributes = _stmt.getText(_columnIndexOfAttributes)
          val _tmpResource: String
          _tmpResource = _stmt.getText(_columnIndexOfResource)
          val _tmpInstrumentationScopeName: String?
          if (_stmt.isNull(_columnIndexOfInstrumentationScopeName)) {
            _tmpInstrumentationScopeName = null
          } else {
            _tmpInstrumentationScopeName = _stmt.getText(_columnIndexOfInstrumentationScopeName)
          }
          val _tmpInstrumentationScopeVersion: String?
          if (_stmt.isNull(_columnIndexOfInstrumentationScopeVersion)) {
            _tmpInstrumentationScopeVersion = null
          } else {
            _tmpInstrumentationScopeVersion = _stmt.getText(_columnIndexOfInstrumentationScopeVersion)
          }
          val _tmpTraceId: String?
          if (_stmt.isNull(_columnIndexOfTraceId)) {
            _tmpTraceId = null
          } else {
            _tmpTraceId = _stmt.getText(_columnIndexOfTraceId)
          }
          val _tmpSpanId: String?
          if (_stmt.isNull(_columnIndexOfSpanId)) {
            _tmpSpanId = null
          } else {
            _tmpSpanId = _stmt.getText(_columnIndexOfSpanId)
          }
          val _tmpAttributeTypes: String?
          if (_stmt.isNull(_columnIndexOfAttributeTypes)) {
            _tmpAttributeTypes = null
          } else {
            _tmpAttributeTypes = _stmt.getText(_columnIndexOfAttributeTypes)
          }
          val _tmpMonotonicMs: Long
          _tmpMonotonicMs = _stmt.getLong(_columnIndexOfMonotonicMs)
          val _tmpBootId: String?
          if (_stmt.isNull(_columnIndexOfBootId)) {
            _tmpBootId = null
          } else {
            _tmpBootId = _stmt.getText(_columnIndexOfBootId)
          }
          val _tmpSeqId: Long
          _tmpSeqId = _stmt.getLong(_columnIndexOfSeqId)
          _item = LogRecordEntity(_tmpId,_tmpTimestampMs,_tmpSeverityText,_tmpBody,_tmpAttributes,_tmpResource,_tmpInstrumentationScopeName,_tmpInstrumentationScopeVersion,_tmpTraceId,_tmpSpanId,_tmpAttributeTypes,_tmpMonotonicMs,_tmpBootId,_tmpSeqId)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getEventsInWindowDualClock(
    monoStartMs: Long,
    wallStartMs: Long,
    currentBootId: String,
  ): List<LogRecordEntity> {
    val _sql: String = """
        |
        |        SELECT * FROM log_records
        |        WHERE (bootId = ? AND monotonicMs >= ?)
        |           OR ((bootId IS NULL OR bootId != ?) AND timestampMs >= ?)
        |        ORDER BY timestampMs ASC
        |    
        """.trimMargin()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, currentBootId)
        _argIndex = 2
        _stmt.bindLong(_argIndex, monoStartMs)
        _argIndex = 3
        _stmt.bindText(_argIndex, currentBootId)
        _argIndex = 4
        _stmt.bindLong(_argIndex, wallStartMs)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfTimestampMs: Int = getColumnIndexOrThrow(_stmt, "timestampMs")
        val _columnIndexOfSeverityText: Int = getColumnIndexOrThrow(_stmt, "severityText")
        val _columnIndexOfBody: Int = getColumnIndexOrThrow(_stmt, "body")
        val _columnIndexOfAttributes: Int = getColumnIndexOrThrow(_stmt, "attributes")
        val _columnIndexOfResource: Int = getColumnIndexOrThrow(_stmt, "resource")
        val _columnIndexOfInstrumentationScopeName: Int = getColumnIndexOrThrow(_stmt, "instrumentationScopeName")
        val _columnIndexOfInstrumentationScopeVersion: Int = getColumnIndexOrThrow(_stmt, "instrumentationScopeVersion")
        val _columnIndexOfTraceId: Int = getColumnIndexOrThrow(_stmt, "traceId")
        val _columnIndexOfSpanId: Int = getColumnIndexOrThrow(_stmt, "spanId")
        val _columnIndexOfAttributeTypes: Int = getColumnIndexOrThrow(_stmt, "attributeTypes")
        val _columnIndexOfMonotonicMs: Int = getColumnIndexOrThrow(_stmt, "monotonicMs")
        val _columnIndexOfBootId: Int = getColumnIndexOrThrow(_stmt, "bootId")
        val _columnIndexOfSeqId: Int = getColumnIndexOrThrow(_stmt, "seqId")
        val _result: MutableList<LogRecordEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: LogRecordEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpTimestampMs: Long
          _tmpTimestampMs = _stmt.getLong(_columnIndexOfTimestampMs)
          val _tmpSeverityText: String?
          if (_stmt.isNull(_columnIndexOfSeverityText)) {
            _tmpSeverityText = null
          } else {
            _tmpSeverityText = _stmt.getText(_columnIndexOfSeverityText)
          }
          val _tmpBody: String
          _tmpBody = _stmt.getText(_columnIndexOfBody)
          val _tmpAttributes: String
          _tmpAttributes = _stmt.getText(_columnIndexOfAttributes)
          val _tmpResource: String
          _tmpResource = _stmt.getText(_columnIndexOfResource)
          val _tmpInstrumentationScopeName: String?
          if (_stmt.isNull(_columnIndexOfInstrumentationScopeName)) {
            _tmpInstrumentationScopeName = null
          } else {
            _tmpInstrumentationScopeName = _stmt.getText(_columnIndexOfInstrumentationScopeName)
          }
          val _tmpInstrumentationScopeVersion: String?
          if (_stmt.isNull(_columnIndexOfInstrumentationScopeVersion)) {
            _tmpInstrumentationScopeVersion = null
          } else {
            _tmpInstrumentationScopeVersion = _stmt.getText(_columnIndexOfInstrumentationScopeVersion)
          }
          val _tmpTraceId: String?
          if (_stmt.isNull(_columnIndexOfTraceId)) {
            _tmpTraceId = null
          } else {
            _tmpTraceId = _stmt.getText(_columnIndexOfTraceId)
          }
          val _tmpSpanId: String?
          if (_stmt.isNull(_columnIndexOfSpanId)) {
            _tmpSpanId = null
          } else {
            _tmpSpanId = _stmt.getText(_columnIndexOfSpanId)
          }
          val _tmpAttributeTypes: String?
          if (_stmt.isNull(_columnIndexOfAttributeTypes)) {
            _tmpAttributeTypes = null
          } else {
            _tmpAttributeTypes = _stmt.getText(_columnIndexOfAttributeTypes)
          }
          val _tmpMonotonicMs: Long
          _tmpMonotonicMs = _stmt.getLong(_columnIndexOfMonotonicMs)
          val _tmpBootId: String?
          if (_stmt.isNull(_columnIndexOfBootId)) {
            _tmpBootId = null
          } else {
            _tmpBootId = _stmt.getText(_columnIndexOfBootId)
          }
          val _tmpSeqId: Long
          _tmpSeqId = _stmt.getLong(_columnIndexOfSeqId)
          _item = LogRecordEntity(_tmpId,_tmpTimestampMs,_tmpSeverityText,_tmpBody,_tmpAttributes,_tmpResource,_tmpInstrumentationScopeName,_tmpInstrumentationScopeVersion,_tmpTraceId,_tmpSpanId,_tmpAttributeTypes,_tmpMonotonicMs,_tmpBootId,_tmpSeqId)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun deleteOlderThan(expiryMs: Long): Int {
    val _sql: String = "DELETE FROM log_records WHERE timestampMs < ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, expiryMs)
        _stmt.step()
        getTotalChangedRows(_connection)
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun deleteEventsAfter(startMs: Long): Int {
    val _sql: String = "DELETE FROM log_records WHERE timestampMs >= ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, startMs)
        _stmt.step()
        getTotalChangedRows(_connection)
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun deleteByIds(ids: List<Long>): Int {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("DELETE FROM log_records WHERE id IN (")
    val _inputSize: Int = ids.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(")")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        for (_item: Long in ids) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        _stmt.step()
        getTotalChangedRows(_connection)
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun deleteBySeqIds(seqIds: List<Long>): Int {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("DELETE FROM log_records WHERE seqId IN (")
    val _inputSize: Int = seqIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") AND seqId > 0")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        for (_item: Long in seqIds) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        _stmt.step()
        getTotalChangedRows(_connection)
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun deleteOldest(count: Int): Int {
    val _sql: String = "DELETE FROM log_records WHERE id IN (SELECT id FROM log_records ORDER BY timestampMs ASC LIMIT ?)"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, count.toLong())
        _stmt.step()
        getTotalChangedRows(_connection)
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun deleteAll(): Int {
    val _sql: String = "DELETE FROM log_records"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        _stmt.step()
        getTotalChangedRows(_connection)
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun deleteEventsByTraceId(traceId: String): Int {
    val _sql: String = "DELETE FROM log_records WHERE traceId = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, traceId)
        _stmt.step()
        getTotalChangedRows(_connection)
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun deleteLowestSeverity(count: Int): Int {
    val _sql: String = """
        |
        |        DELETE FROM log_records WHERE id IN (
        |            SELECT id FROM log_records
        |            ORDER BY
        |                CASE severityText
        |                    WHEN 'TRACE' THEN 0
        |                    WHEN 'DEBUG' THEN 1
        |                    WHEN 'INFO' THEN 2
        |                    WHEN 'WARN' THEN 3
        |                    WHEN 'ERROR' THEN 4
        |                    WHEN 'FATAL' THEN 5
        |                    ELSE 1
        |                END ASC,
        |                timestampMs ASC
        |            LIMIT ?
        |        )
        |    
        """.trimMargin()
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, count.toLong())
        _stmt.step()
        getTotalChangedRows(_connection)
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
