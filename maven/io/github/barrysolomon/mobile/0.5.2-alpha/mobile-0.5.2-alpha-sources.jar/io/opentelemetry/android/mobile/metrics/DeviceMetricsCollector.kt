/*
 * Copyright The OpenTelemetry Authors
 * SPDX-License-Identifier: Apache-2.0
 */

package io.opentelemetry.android.mobile.metrics

import android.Manifest
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.os.StatFs
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.annotation.RequiresPermission
import io.opentelemetry.api.metrics.Meter
import io.opentelemetry.api.common.AttributeKey
import io.opentelemetry.api.common.Attributes
import java.io.File
import java.util.concurrent.atomic.AtomicLong

/**
 * Collects device health metrics on-demand for export during crashes or trigger events.
 *
 * Follows OpenTelemetry semantic conventions for device and system metrics.
 * Designed for mobile: lightweight, fast capture, privacy-safe.
 *
 * Usage:
 * ```kotlin
 * val collector = DeviceMetricsCollector(context, meter, config)
 *
 * // Capture all configured metrics
 * collector.captureMetrics(CaptureReason.CRASH)
 *
 * // Query specific metrics
 * val memoryMb = collector.getAvailableMemoryMb()
 * val batteryPercent = collector.getBatteryLevel()
 * ```
 */
class DeviceMetricsCollector(
    private val context: Context,
    private val meter: Meter,
    private val config: DeviceMetricsConfig
) {
    private val lastCaptureTime = AtomicLong(0)

    /**
     * Captures all configured metrics based on configuration.
     *
     * @param reason Why metrics are being captured
     * @param force Force capture even if rate-limited
     * @return true if metrics were captured, false if rate-limited
     */
    @RequiresPermission(Manifest.permission.ACCESS_NETWORK_STATE)
    fun captureMetrics(reason: CaptureReason, force: Boolean = false): Boolean {
        val now = System.currentTimeMillis()
        val lastCapture = lastCaptureTime.get()
        val rateLimitMs = 60 * 1000L  // 60 seconds default

        // Check rate limit unless forced
        if (!force && (now - lastCapture) < rateLimitMs) {
            return false
        }

        lastCaptureTime.set(now)

        val baseAttributes = Attributes.builder()
            .put(AttributeKey.stringKey("mobile.capture.reason"), reason.name.lowercase())
            .put(AttributeKey.longKey("mobile.capture.timestamp_ms"), now)
            .build()

        // Capture configured metrics
        if (config.captureMemory) captureMemoryMetrics(baseAttributes)
        if (config.captureBattery) captureBatteryMetrics(baseAttributes)
        if (config.captureCpu) captureCpuMetrics(baseAttributes)
        if (config.captureNetwork) captureNetworkMetrics(baseAttributes)
        if (config.captureStorage) captureStorageMetrics(baseAttributes)
        if (config.captureThermal) captureThermalMetrics(baseAttributes)
        if (config.captureDisplay) captureDisplayMetrics(baseAttributes)
        if (config.captureSystem) captureSystemMetrics(baseAttributes)
        if (config.captureApp) captureAppMetrics(baseAttributes)
        if (config.captureLocation) captureLocationMetrics(baseAttributes)

        return true
    }

    /**
     * Memory metrics: used, available, total, low memory state.
     */
    private fun captureMemoryMetrics(attributes: Attributes) {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memInfo)

        val availableBytes = memInfo.availMem
        val totalBytes = memInfo.totalMem
        val usedBytes = totalBytes - availableBytes

        // Record memory metrics as upDownCounters (snapshot metrics — values fluctuate)
        // Unit: "By" per OTel semconv (UCUM bytes)
        meter.upDownCounterBuilder("system.memory.usage")
            .setDescription("Memory currently used by app")
            .setUnit("By")
            .build()
            .add(usedBytes, attributes)

        meter.upDownCounterBuilder("system.memory.available")
            .setDescription("Memory available to app")
            .setUnit("By")
            .build()
            .add(availableBytes, attributes)

        // Low memory flag
        meter.upDownCounterBuilder("device.memory.low_memory")
            .setDescription("Low memory state detected (1=low, 0=normal)")
            .build()
            .add(if (memInfo.lowMemory) 1 else 0, attributes)
    }

    /**
     * Battery metrics: level, charging state, health, temperature.
     */
    private fun captureBatteryMetrics(attributes: Attributes) {
        val batteryIntent = context.registerReceiver(
            null,
            IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        )

        if (batteryIntent != null) {
            val level = batteryIntent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = batteryIntent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            val batteryPercent = if (scale > 0) (level * 100 / scale) else -1

            val temperature = batteryIntent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1)
            val tempCelsius = if (temperature > 0) temperature / 10.0 else -1.0

            val status = batteryIntent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                    status == BatteryManager.BATTERY_STATUS_FULL

            val health = batteryIntent.getIntExtra(BatteryManager.EXTRA_HEALTH, -1)

            // Record battery metrics as counters (snapshot metrics)
            val batteryAttributes = Attributes.builder()
                .putAll(attributes)
                .put(AttributeKey.booleanKey("mobile.battery.charging"), isCharging)
                .put(AttributeKey.stringKey("mobile.battery.health"), getBatteryHealthString(health))
                .build()

            if (batteryPercent >= 0) {
                meter.upDownCounterBuilder("system.battery.charge")
                    .setDescription("Battery charge level percentage (0-100)")
                    .setUnit("%")
                    .build()
                    .add(batteryPercent.toLong(), batteryAttributes)
            }

            if (tempCelsius > 0) {
                meter.upDownCounterBuilder("system.battery.temperature")
                    .setDescription("Battery temperature in Celsius")
                    .setUnit("Cel")
                    .ofDoubles()
                    .build()
                    .add(tempCelsius, batteryAttributes)
            }
        }
    }

    /**
     * CPU metrics: usage, core count, architecture.
     */
    private fun captureCpuMetrics(attributes: Attributes) {
        // CPU core count
        val coreCount = Runtime.getRuntime().availableProcessors()

        // CPU usage (simplified - would need /proc/stat for accuracy)
        // For now, just report core count and architecture
        val cpuAttributes = Attributes.builder()
            .putAll(attributes)
            .put(AttributeKey.longKey("mobile.cpu.core_count"), coreCount.toLong())
            .put(AttributeKey.stringKey("mobile.cpu.architecture"), Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown")
            .build()

        meter.upDownCounterBuilder("system.cpu.info")
            .setDescription("CPU info snapshot (1 = present, attributes carry detail)")
            .build()
            .add(1, cpuAttributes)
    }

    /**
     * Network metrics: type, connection state, capabilities.
     */
    @RequiresPermission(Manifest.permission.ACCESS_NETWORK_STATE)
    private fun captureNetworkMetrics(attributes: Attributes) {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = connectivityManager.activeNetwork
        val capabilities = network?.let { connectivityManager.getNetworkCapabilities(it) }

        val networkType = when {
            capabilities == null -> "none"
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "wifi"
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "cellular"
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "ethernet"
            else -> "unknown"
        }

        val isConnected = capabilities != null

        val networkAttributes = Attributes.builder()
            .putAll(attributes)
            .put(AttributeKey.stringKey("network.connection.type"), networkType)
            .put(AttributeKey.booleanKey("mobile.network.connected"), isConnected)
            .build()

        meter.upDownCounterBuilder("system.network.connections")
            .setDescription("Network connection state snapshot (1=connected, 0=disconnected)")
            .build()
            .add(if (isConnected) 1 else 0, networkAttributes)
    }

    /**
     * Storage metrics: used, available, cache size.
     */
    private fun captureStorageMetrics(attributes: Attributes) {
        val stat = StatFs(Environment.getDataDirectory().path)
        val totalBytes = stat.blockCountLong * stat.blockSizeLong
        val availableBytes = stat.availableBlocksLong * stat.blockSizeLong
        val usedBytes = totalBytes - availableBytes

        // Record storage metrics as upDownCounters (snapshot — values fluctuate)
        // Unit: "By" per OTel semconv (UCUM bytes)
        meter.upDownCounterBuilder("system.filesystem.usage")
            .setDescription("Internal storage used")
            .setUnit("By")
            .build()
            .add(usedBytes, attributes)

        meter.upDownCounterBuilder("system.filesystem.available")
            .setDescription("Internal storage available")
            .setUnit("By")
            .build()
            .add(availableBytes, attributes)

        // Cache size
        val cacheDir = context.cacheDir
        val cacheSize = getFolderSize(cacheDir)

        meter.upDownCounterBuilder("device.storage.cache")
            .setDescription("App cache directory size")
            .setUnit("By")
            .build()
            .add(cacheSize, attributes)
    }

    /**
     * Thermal metrics: throttling state.
     */
    private fun captureThermalMetrics(attributes: Attributes) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            val thermalStatus = powerManager.currentThermalStatus

            // Map to 0-4 scale
            val thermalLevel = when (thermalStatus) {
                PowerManager.THERMAL_STATUS_NONE -> 0L
                PowerManager.THERMAL_STATUS_LIGHT -> 1L
                PowerManager.THERMAL_STATUS_MODERATE -> 2L
                PowerManager.THERMAL_STATUS_SEVERE -> 3L
                PowerManager.THERMAL_STATUS_CRITICAL,
                PowerManager.THERMAL_STATUS_EMERGENCY,
                PowerManager.THERMAL_STATUS_SHUTDOWN -> 4L
                else -> 0L
            }

            // Record thermal state as upDownCounter (snapshot metric — fluctuates)
            meter.upDownCounterBuilder("device.thermal.state")
                .setDescription("Thermal throttling state (0=none, 1=light, 2=moderate, 3=severe, 4=critical)")
                .build()
                .add(thermalLevel, attributes)
        }
    }

    /**
     * Display metrics: orientation, resolution, screen state.
     */
    private fun captureDisplayMetrics(attributes: Attributes) {
        val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val displayMetrics = DisplayMetrics()
        windowManager.defaultDisplay.getMetrics(displayMetrics)

        val displayAttributes = Attributes.builder()
            .putAll(attributes)
            .put(AttributeKey.longKey("mobile.display.width_px"), displayMetrics.widthPixels.toLong())
            .put(AttributeKey.longKey("mobile.display.height_px"), displayMetrics.heightPixels.toLong())
            .put(AttributeKey.doubleKey("mobile.display.density"), displayMetrics.density.toDouble())
            .build()

        meter.upDownCounterBuilder("device.display.info")
            .setDescription("Display info snapshot (1 = present, attributes carry detail)")
            .build()
            .add(1, displayAttributes)
    }

    /**
     * System metrics: OS version, API level, uptime.
     */
    private fun captureSystemMetrics(attributes: Attributes) {
        val systemAttributes = Attributes.builder()
            .putAll(attributes)
            .put(AttributeKey.stringKey("os.version"), Build.VERSION.RELEASE)
            .put(AttributeKey.longKey("mobile.os.api_level"), Build.VERSION.SDK_INT.toLong())
            .put(AttributeKey.stringKey("device.model.name"), Build.MODEL)
            .put(AttributeKey.stringKey("device.manufacturer"), Build.MANUFACTURER)
            .put(AttributeKey.longKey("mobile.system.uptime_ms"), android.os.SystemClock.elapsedRealtime())
            .build()

        meter.upDownCounterBuilder("device.system.info")
            .setDescription("System info snapshot (1 = present, attributes carry detail)")
            .build()
            .add(1, systemAttributes)
    }

    /**
     * App metrics: version, foreground state, install time.
     */
    private fun captureAppMetrics(attributes: Attributes) {
        val packageInfo = context.packageManager.getPackageInfo(context.packageName, 0)
        val versionName = packageInfo.versionName ?: "unknown"
        val versionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            packageInfo.longVersionCode
        } else {
            @Suppress("DEPRECATION")
            packageInfo.versionCode.toLong()
        }

        val appAttributes = Attributes.builder()
            .putAll(attributes)
            .put(AttributeKey.stringKey("mobile.app.version"), versionName)
            .put(AttributeKey.longKey("mobile.app.version_code"), versionCode)
            .put(AttributeKey.longKey("mobile.app.install_time_ms"), packageInfo.firstInstallTime)
            .put(AttributeKey.longKey("mobile.app.update_time_ms"), packageInfo.lastUpdateTime)
            .build()

        meter.upDownCounterBuilder("device.app.info")
            .setDescription("App info snapshot (1 = present, attributes carry detail)")
            .build()
            .add(1, appAttributes)
    }

    /**
     * Location metrics: coarse location (country, timezone) - privacy-safe.
     */
    private fun captureLocationMetrics(attributes: Attributes) {
        // Only capture coarse, privacy-safe location data
        val timezone = java.util.TimeZone.getDefault().id
        val country = java.util.Locale.getDefault().country

        val locationAttributes = Attributes.builder()
            .putAll(attributes)
            .put(AttributeKey.stringKey("mobile.geo.timezone"), timezone)
            .put(AttributeKey.stringKey("mobile.geo.country"), country)
            .build()

        meter.upDownCounterBuilder("device.location.info")
            .setDescription("Location info snapshot (1 = present, attributes carry detail)")
            .build()
            .add(1, locationAttributes)
    }

    // Helper methods

    fun getAvailableMemoryMb(): Long {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memInfo)
        return memInfo.availMem / (1024 * 1024)
    }

    fun getBatteryLevel(): Int {
        val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        return if (batteryIntent != null) {
            val level = batteryIntent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = batteryIntent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            if (scale > 0) (level * 100 / scale) else -1
        } else {
            -1
        }
    }

    private fun getBatteryHealthString(health: Int): String {
        return when (health) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "good"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "overheat"
            BatteryManager.BATTERY_HEALTH_DEAD -> "dead"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "over_voltage"
            BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "failure"
            BatteryManager.BATTERY_HEALTH_COLD -> "cold"
            else -> "unknown"
        }
    }

    private fun getFolderSize(file: File): Long {
        var size: Long = 0
        if (file.isDirectory) {
            file.listFiles()?.forEach { child ->
                size += getFolderSize(child)
            }
        } else {
            size = file.length()
        }
        return size
    }
}

/**
 * Reason why device metrics are being captured.
 */
enum class CaptureReason {
    APP_START,
    FORCE_CLOSE,
    CRASH,
    ERROR,
    MANUAL_FLUSH,
    SCHEDULED_FLUSH,
    WORKFLOW_TRIGGER,
    MANUAL_CAPTURE
}
