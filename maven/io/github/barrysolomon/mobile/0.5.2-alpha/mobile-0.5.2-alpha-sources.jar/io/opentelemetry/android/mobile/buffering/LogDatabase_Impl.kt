package io.opentelemetry.android.mobile.buffering

import androidx.room.InvalidationTracker
import androidx.room.RoomOpenDelegate
import androidx.room.migration.AutoMigrationSpec
import androidx.room.migration.Migration
import androidx.room.util.TableInfo
import androidx.room.util.TableInfo.Companion.read
import androidx.room.util.dropFtsSyncTriggers
import androidx.sqlite.SQLiteConnection
import androidx.sqlite.execSQL
import javax.`annotation`.processing.Generated
import kotlin.Lazy
import kotlin.String
import kotlin.Suppress
import kotlin.collections.List
import kotlin.collections.Map
import kotlin.collections.MutableList
import kotlin.collections.MutableMap
import kotlin.collections.MutableSet
import kotlin.collections.Set
import kotlin.collections.mutableListOf
import kotlin.collections.mutableMapOf
import kotlin.collections.mutableSetOf
import kotlin.reflect.KClass

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
internal class LogDatabase_Impl : LogDatabase() {
  private val _logDao: Lazy<LogDao> = lazy {
    LogDao_Impl(this)
  }

  protected override fun createOpenDelegate(): RoomOpenDelegate {
    val _openDelegate: RoomOpenDelegate = object : RoomOpenDelegate(4, "7d5e5d87d889d79b797fc4a5c50ee13f", "785e147d92e3f2f6b4e2e5f2274c8682") {
      public override fun createAllTables(connection: SQLiteConnection) {
        connection.execSQL("CREATE TABLE IF NOT EXISTS `log_records` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `timestampMs` INTEGER NOT NULL, `severityText` TEXT, `body` TEXT NOT NULL, `attributes` TEXT NOT NULL, `resource` TEXT NOT NULL, `instrumentationScopeName` TEXT, `instrumentationScopeVersion` TEXT, `traceId` TEXT, `spanId` TEXT, `attributeTypes` TEXT, `monotonicMs` INTEGER NOT NULL, `bootId` TEXT, `seqId` INTEGER NOT NULL)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_log_records_timestampMs` ON `log_records` (`timestampMs`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_log_records_traceId` ON `log_records` (`traceId`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_log_records_monotonicMs` ON `log_records` (`monotonicMs`)")
        connection.execSQL("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)")
        connection.execSQL("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, '7d5e5d87d889d79b797fc4a5c50ee13f')")
      }

      public override fun dropAllTables(connection: SQLiteConnection) {
        connection.execSQL("DROP TABLE IF EXISTS `log_records`")
      }

      public override fun onCreate(connection: SQLiteConnection) {
      }

      public override fun onOpen(connection: SQLiteConnection) {
        internalInitInvalidationTracker(connection)
      }

      public override fun onPreMigrate(connection: SQLiteConnection) {
        dropFtsSyncTriggers(connection)
      }

      public override fun onPostMigrate(connection: SQLiteConnection) {
      }

      public override fun onValidateSchema(connection: SQLiteConnection): RoomOpenDelegate.ValidationResult {
        val _columnsLogRecords: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsLogRecords.put("id", TableInfo.Column("id", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsLogRecords.put("timestampMs", TableInfo.Column("timestampMs", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsLogRecords.put("severityText", TableInfo.Column("severityText", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsLogRecords.put("body", TableInfo.Column("body", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsLogRecords.put("attributes", TableInfo.Column("attributes", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsLogRecords.put("resource", TableInfo.Column("resource", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsLogRecords.put("instrumentationScopeName", TableInfo.Column("instrumentationScopeName", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsLogRecords.put("instrumentationScopeVersion", TableInfo.Column("instrumentationScopeVersion", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsLogRecords.put("traceId", TableInfo.Column("traceId", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsLogRecords.put("spanId", TableInfo.Column("spanId", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsLogRecords.put("attributeTypes", TableInfo.Column("attributeTypes", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsLogRecords.put("monotonicMs", TableInfo.Column("monotonicMs", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsLogRecords.put("bootId", TableInfo.Column("bootId", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsLogRecords.put("seqId", TableInfo.Column("seqId", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysLogRecords: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        val _indicesLogRecords: MutableSet<TableInfo.Index> = mutableSetOf()
        _indicesLogRecords.add(TableInfo.Index("index_log_records_timestampMs", false, listOf("timestampMs"), listOf("ASC")))
        _indicesLogRecords.add(TableInfo.Index("index_log_records_traceId", false, listOf("traceId"), listOf("ASC")))
        _indicesLogRecords.add(TableInfo.Index("index_log_records_monotonicMs", false, listOf("monotonicMs"), listOf("ASC")))
        val _infoLogRecords: TableInfo = TableInfo("log_records", _columnsLogRecords, _foreignKeysLogRecords, _indicesLogRecords)
        val _existingLogRecords: TableInfo = read(connection, "log_records")
        if (!_infoLogRecords.equals(_existingLogRecords)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |log_records(io.opentelemetry.android.mobile.buffering.LogRecordEntity).
              | Expected:
              |""".trimMargin() + _infoLogRecords + """
              |
              | Found:
              |""".trimMargin() + _existingLogRecords)
        }
        return RoomOpenDelegate.ValidationResult(true, null)
      }
    }
    return _openDelegate
  }

  protected override fun createInvalidationTracker(): InvalidationTracker {
    val _shadowTablesMap: MutableMap<String, String> = mutableMapOf()
    val _viewTables: MutableMap<String, Set<String>> = mutableMapOf()
    return InvalidationTracker(this, _shadowTablesMap, _viewTables, "log_records")
  }

  public override fun clearAllTables() {
    super.performClear(false, "log_records")
  }

  protected override fun getRequiredTypeConverterClasses(): Map<KClass<*>, List<KClass<*>>> {
    val _typeConvertersMap: MutableMap<KClass<*>, List<KClass<*>>> = mutableMapOf()
    _typeConvertersMap.put(LogDao::class, LogDao_Impl.getRequiredConverters())
    return _typeConvertersMap
  }

  public override fun getRequiredAutoMigrationSpecClasses(): Set<KClass<out AutoMigrationSpec>> {
    val _autoMigrationSpecsSet: MutableSet<KClass<out AutoMigrationSpec>> = mutableSetOf()
    return _autoMigrationSpecsSet
  }

  public override fun createAutoMigrations(autoMigrationSpecs: Map<KClass<out AutoMigrationSpec>, AutoMigrationSpec>): List<Migration> {
    val _autoMigrations: MutableList<Migration> = mutableListOf()
    return _autoMigrations
  }

  public override fun logDao(): LogDao = _logDao.value
}
